const express = require("express");
const { PrismaClient } = require("@prisma/client");
const authenticateAPIKey = require("../middleware/authMiddleware");

const prisma = new PrismaClient();
const router = express.Router();

/**
 * @route   POST /api/doctor/add
 * @desc    Add a new doctor
 */
router.post("/add", authenticateAPIKey, async (req, res) => {
  try {
    const {
      name,
      contactNumber,
      contactNumberSerial,
      designation,
      gender,
      profilePhoto,
      email,
      department,
      shortBio,
      appointmentFee,
      followUpFee,
      patientAttended,
      avgConsultationTime,
      academicqualiifcation,
      yearexperiences,
      memberships,
      awardsAchievements,
      treatmentsList,
      conditionsList,
      schedule,
      faqs
    } = req.body;

    const newDoctor = await prisma.doctor.create({
      data: {
        name,
        contactNumber,
        contactNumberSerial,
        designation,
        gender,
        profilePhoto,
        email,
        department,
        shortBio,
        appointmentFee: parseFloat(appointmentFee),
        followUpFee: parseFloat(followUpFee),
        patientAttended: parseInt(patientAttended),
        avgConsultationTime: parseInt(avgConsultationTime),
        academicqualiifcation,
        yearexperiences: parseInt(yearexperiences),
        memberships: {
          create: memberships.map(mem => ({ name: mem }))
        },
        awards: {
          create: awardsAchievements.map(award => ({ title: award }))
        },
        treatments: {
          create: treatmentsList.map(treatment => ({ name: treatment }))
        },
        conditions: {
          create: conditionsList.map(condition => ({ name: condition }))
        },
        schedule: {
          create: schedule.map(sch => ({
            day: sch.day,
            startTime: sch.startTime,
            endTime: sch.endTime
          }))
        },
        faqs: {
          create: faqs.map(faq => ({
            question: faq.question,
            answer: faq.answer
          }))
        }
      }
    });

    res.status(201).json({ message: "Doctor added successfully", doctor: newDoctor });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

/**
 * @route   GET /api/doctors
 * @desc    Get all doctors with related data
 */
router.get("/", authenticateAPIKey, async (req, res) => {
  try {
    const doctors = await prisma.doctor.findMany({
      include: {
        memberships: true,
        awards: true,
        treatments: true,
        conditions: true,
        schedule: true,
        faqs: true
      }
    });
    res.status(200).json(doctors);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

/**
 * @route   GET /api/doctors/:id
 * @desc    Get a single doctor by ID
 */
router.get("/:id", authenticateAPIKey, async (req, res) => {
  try {
    const doctor = await prisma.doctor.findUnique({
      where: { id: req.params.id },
      include: {
        memberships: true,
        awards: true,
        treatments: true,
        conditions: true,
        schedule: true,
        faqs: true
      }
    });

    if (!doctor) return res.status(404).json({ error: "Doctor not found" });

    res.status(200).json(doctor);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

/**
 * @route   PUT /api/doctors/edit/:id
 * @desc    Update doctor details
 */
router.put("/edit/:id", authenticateAPIKey, async (req, res) => {
  try {
    const {
      name,
      contactNumber,
      contactNumberSerial,
      designation,
      gender,
      profilePhoto,
      email,
      department,
      shortBio,
      appointmentFee,
      followUpFee,
      patientAttended,
      avgConsultationTime,
      academicqualiifcation,
      yearexperiences,
      memberships,
      awardsAchievements,
      treatmentsList,
      conditionsList,
      schedule,
      faqs
    } = req.body;

    // Ensure ID is formatted correctly
    const doctorId = req.params.id.trim();

    // Check if the doctor exists
    const existingDoctor = await prisma.doctor.findUnique({
      where: { id: doctorId },
    });

    if (!existingDoctor) {
      return res.status(404).json({ error: "Doctor not found" });
    }

    // Build update data for scalar fields and conditionally for nested relations.
    const updateData = {
      name: name || existingDoctor.name,
      contactNumber: contactNumber || existingDoctor.contactNumber,
      contactNumberSerial: contactNumberSerial || existingDoctor.contactNumberSerial,
      designation: designation || existingDoctor.designation,
      gender: gender || existingDoctor.gender,
      profilePhoto: profilePhoto || existingDoctor.profilePhoto,
      email: email || existingDoctor.email,
      department: department || existingDoctor.department,
      shortBio: shortBio || existingDoctor.shortBio,
      appointmentFee: appointmentFee ? parseFloat(appointmentFee) : existingDoctor.appointmentFee,
      followUpFee: followUpFee ? parseFloat(followUpFee) : existingDoctor.followUpFee,
      patientAttended: patientAttended ? parseInt(patientAttended) : existingDoctor.patientAttended,
      avgConsultationTime: avgConsultationTime ? parseInt(avgConsultationTime) : existingDoctor.avgConsultationTime,
      academicqualiifcation: academicqualiifcation || existingDoctor.academicqualiifcation,
      yearexperiences: yearexperiences ? parseInt(yearexperiences) : existingDoctor.yearexperiences,
      // If these nested arrays are provided, delete the existing relations and create new ones.
      memberships: memberships
        ? {
            deleteMany: {},
            create: memberships.map(mem => ({ name: mem }))
          }
        : undefined,
      awards: awardsAchievements
        ? {
            deleteMany: {},
            create: awardsAchievements.map(award => ({ title: award }))
          }
        : undefined,
      treatments: treatmentsList
        ? {
            deleteMany: {},
            create: treatmentsList.map(treatment => ({ name: treatment }))
          }
        : undefined,
      conditions: conditionsList
        ? {
            deleteMany: {},
            create: conditionsList.map(condition => ({ name: condition }))
          }
        : undefined,
      schedule: schedule
        ? {
            deleteMany: {},
            create: schedule.map(sch => ({
              day: sch.day,
              startTime: sch.startTime,
              endTime: sch.endTime
            }))
          }
        : undefined,
      faqs: faqs
        ? {
            deleteMany: {},
            create: faqs.map(faq => ({
              question: faq.question,
              answer: faq.answer
            }))
          }
        : undefined,
    };

    // Perform the update including nested writes (if provided)
    const updatedDoctor = await prisma.doctor.update({
      where: { id: doctorId },
      data: updateData,
      include: {
        memberships: true,
        awards: true,
        treatments: true,
        conditions: true,
        schedule: true,
        faqs: true
      }
    });

    res.status(200).json({ message: "Doctor updated successfully", doctor: updatedDoctor });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

/**
 * @route   DELETE /api/doctors/delete/:id
 * @desc    Delete a doctor by ID
 */
router.delete("/delete/:id", authenticateAPIKey, async (req, res) => {
  try {
    await prisma.doctor.delete({
      where: { id: req.params.id }
    });

    res.status(200).json({ message: "Doctor deleted successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = router;
