const express = require('express');
const { PrismaClient } = require("@prisma/client");
const authenticateAPIKey = require('../middleware/authMiddleware');

const prisma = new PrismaClient();
const router = express.Router();

/**
 * @route   POST /api/patient/add
 * @desc    Add a new patient
 */
router.post("/add",authenticateAPIKey, async (req, res) => {
    try {
        const { name, phoneNumber, email, gender, bloodGroup, dateOfBirth, age, weight, image } = req.body;
        
        const newPatient = await prisma.patient.create({
            data: {
                name,
                phoneNumber,
                email,
                gender,
                bloodGroup,
                dateOfBirth: new Date(dateOfBirth), // Ensure date format is valid
                age: parseInt(age),
                weight: parseFloat(weight),
                image
            }
        });

        res.status(201).json({ message: "Patient added successfully", patient: newPatient });

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
});
/**
 * @route   GET /api/patient
 * @desc    Get all patient with related data
 */
router.get("/",authenticateAPIKey,async(req,res)=>{
    try {
        const patient=await prisma.patient.findMany();
        res.status(200).json(patient)
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
})
/**
 * @route   GET /api/patient/:id
 * @desc    Get all patient with related data
 */
router.get("/:id",authenticateAPIKey,async(req,res)=>{
    try {
        const patient=await prisma.patient.findUnique({
            where:{id:req.params.id}
        });
        if(!patient) return res.status(404).json({error:"Patient not found"});
        res.status(200).json(patient)
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
})
/**
 * @route   PUT /api/patient/edit/:id
 * @desc    update patient details
 */

router.put("/edit/:id", authenticateAPIKey, async (req, res) => {
    try {
        const { name, phoneNumber, email, gender, bloodGroup, dateOfBirth, age, weight, image } = req.body;

        // Ensure ID is formatted correctly
        const patientId = req.params.id.trim();

        // Check if the patient exists
        const existingPatient = await prisma.patient.findUnique({
            where: { id: patientId },
        });

        if (!existingPatient) {
            return res.status(404).json({ error: "Patient not found" });
        }

        // Ensure all fields have valid values
        const updateData = {
            name: name || existingPatient.name,
            phoneNumber: phoneNumber || existingPatient.phoneNumber,
            email: email || existingPatient.email,
            gender: gender || existingPatient.gender,
            bloodGroup: bloodGroup || existingPatient.bloodGroup,
            dateOfBirth: dateOfBirth ? new Date(dateOfBirth) : existingPatient.dateOfBirth,
            age: age ? parseInt(age) : existingPatient.age,
            weight: weight ? parseFloat(weight) : existingPatient.weight,
            image: image || existingPatient.image,
        };

        // Perform update
        const updatedPatient = await prisma.patient.update({
            where: { id: patientId },
            data: updateData,
        });

        res.status(200).json({ message: "Patient updated successfully", patient: updatedPatient });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

/**
 * @route   DELETE /api/patient/delete/:id
 * @desc    delete patient
 */
router.delete("/delete/:id" ,authenticateAPIKey, async(req,res)=>{
    try {
        await prisma.patient.delete({
            where:{id:req.params.id}
        })
        res.status(200).json({message:"Patient deleted successfully"})
    } catch (error) {
        console.error(error);
        res.status(500).json({error: "Internal Server Error"});
    }
})
module.exports = router;
